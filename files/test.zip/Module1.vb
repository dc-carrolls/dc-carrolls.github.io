﻿Module Module1

    Sub Main()
        task1b()
        Console.ReadLine()


    End Sub

    Sub task1()

        Dim input_text As String
        Dim input_num As Integer
        Dim valid_num As Boolean

        For i = 1 To 10
            valid_num = False
            Console.WriteLine("Enter Number")
            Do While Not valid_num
                input_text = Console.ReadLine
                If IsNumeric(input_text) Then
                    Console.WriteLine("Valid number")
                    valid_num = True
                    input_num = CInt(input_text)
                End If
            Loop
            Console.WriteLine(input_num)
        Next i



    End Sub

    Sub task1b()

        Dim input_num As Integer

        For i = 1 To 10
            valid_num = False
            Console.WriteLine("Enter Integer")
            Do While Not Integer.TryParse(Console.ReadLine, input_num)
                Console.WriteLine("Not a valid integer, try again")
            Loop
            Console.WriteLine(input_num & " is a valid integer")
        Next i

    End Sub

End Module
